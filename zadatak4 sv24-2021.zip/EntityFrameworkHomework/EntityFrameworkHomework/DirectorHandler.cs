﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntityFrameworkHomework
{
    internal class DirectorHandler
    {
        private readonly ImdbContext _context;

        public DirectorHandler(ImdbContext context)
        {
            _context = context;
        }

        public void AddDirector(Director director)
        {
            _context.Directors.Add(director);
            _context.SaveChanges();
        }

        public Director GetDirector(int id)
        {
            return _context.Directors.FirstOrDefault(d => d.Id == id);
        }

        public void UpdateDirector(Director updatedDirector)
        {
            var director = _context.Directors.FirstOrDefault(d => d.Id == updatedDirector.Id);
            if (director != null)
            {
                director.Name = updatedDirector.Name;
                director.Oscars = updatedDirector.Oscars;
                director.Born = updatedDirector.Born;
                director.Died = updatedDirector.Died;
                _context.SaveChanges();
            }
            else
            {
                throw new KeyNotFoundException($"Director with ID {updatedDirector.Id} not found.");
            }
        }

        public void DeleteDirector(int id)
        {
            var director = _context.Directors.FirstOrDefault(d => d.Id == id);
            if (director != null)
            {
                _context.Directors.Remove(director);
                _context.SaveChanges();
            }
            else
            {
                throw new KeyNotFoundException($"Director with ID {id} not found.");
            }
        }

        public void DeleteByName(string name)
        {
            var forDelete = _context.Directors.Where(director => director.Name == name).ToList();

            foreach (var director in forDelete)
            {
                DeleteDirector(director.Id);
            }
        }

        public IEnumerable<Director> GetAllDirectors()
        {
            return _context.Directors.ToList();
        }
    }
}
