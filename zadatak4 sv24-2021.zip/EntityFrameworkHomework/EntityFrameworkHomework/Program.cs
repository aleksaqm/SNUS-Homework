﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Infrastructure.Design;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace EntityFrameworkHomework;

internal class Program
{
    static void Main(string[] args)
    {
        const string xmlFilePath = "data.xml";

        var context = new ImdbContext();
        try
        {
            LoadXmlToDatabase(xmlFilePath, context);
            var reportHandler = new ReportHandler(context);


            Console.WriteLine("\nMovies by Director:");
            reportHandler.MoviesByDirector();

            Console.WriteLine("\nMovies with Directors:");
            reportHandler.DirectorForMovies();

            int n = 5;
            Console.WriteLine($"\nTop {n} Ranked Movies:");
            reportHandler.TopNRankedMovies(n);

            Console.WriteLine("\nDirectors and number of Oscars won by their movies:");
            reportHandler.DirectorsAndTheirOscars();

            Console.WriteLine("\nDirectors with More Than Two Oscars won by their movies:");
            reportHandler.DirectorsWithMoreThanTwoOscars();

            Console.WriteLine("\nLiving Directors with At Least Two Oscars:");
            reportHandler.LivingDirectorsWithAtLeastTwoOscars();




            //Console.WriteLine("\n ===== Testing CRUD methods =====\n");
            //var directorHandler = new DirectorHandler(context);
            //var movieHandler = new MovieHandler(context);

            //Console.WriteLine("Testing Create\n");

            //var director = new Director(8, "Martin Scorsese", 10, new DateTime(1942, 11, 22, 0, 0, 0), null);
            //directorHandler.AddDirector(director);
            //var movie = new Movie(13, "Taxi driver", 9.5, 1976, 1, 8, director);
            //movieHandler.AddMovie(movie);
            //Console.WriteLine("Movie and director added successfully");

            //Console.WriteLine("Testing Update\n");
            //var updatedDirector = new Director(8, "Martin Scorsese II", 10, new DateTime(1942, 11, 22, 0,0,0), DateTime.Now);
            //directorHandler.UpdateDirector(updatedDirector);
            //var updatedMovie = new Movie(13, "Taxi driver 2", 9.5, 1976, 2, 8, director);
            //movieHandler.UpdateMovie(updatedMovie);

            //Console.WriteLine("Testing Delete\n");
            //directorHandler.DeleteDirector(8);
            //movieHandler.DeleteMovie(13);



        }
        catch (Exception ex)
        {
            Console.WriteLine($"An error occurred: {ex.Message}");
        }

            
    }

    private static void LoadXmlToDatabase(string xmlFilePath, ImdbContext context)
    {
        var xdoc = XDocument.Load(xmlFilePath);
        var directorElements = xdoc.Descendants("Director");
        var movieElements = xdoc.Descendants("Movie");

        foreach (var d in directorElements)
        {
            var director = new Director
            {
                Id = int.Parse(d.Attribute("id").Value),
                Name = d.Value,
                Oscars = int.Parse(d.Attribute("oscars").Value),
                Born = DateTime.ParseExact(d.Attribute("born").Value, "d.M.yyyy.", CultureInfo.InvariantCulture),
                Died = string.IsNullOrWhiteSpace(d.Attribute("died")?.Value) ? null : DateTime.ParseExact(d.Attribute("died").Value, "d.M.yyyy.", CultureInfo.InvariantCulture)
            };
            if (!context.Directors.Any(e => e.Id == director.Id))
            {
                context.Directors.Add(director);
            }
        }

        foreach (var m in movieElements)
        {
            var movie = new Movie
            {
                Id = int.Parse(m.Attribute("id").Value),
                Title = m.Value,
                Rating = double.Parse(m.Attribute("rating").Value, CultureInfo.InvariantCulture),
                Year = int.Parse(m.Attribute("year").Value),
                Oscars = int.Parse(m.Attribute("oscars").Value),
                DirectorId = int.Parse(m.Attribute("directorId").Value)
            };
            if (!context.Movies.Any(e => e.Id == movie.Id))
            {
                context.Movies.Add(movie);
            }
        }

        context.SaveChanges();
    }
}