﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntityFrameworkHomework
{
    internal class MovieHandler
    {
        private readonly ImdbContext _context;

        public MovieHandler(ImdbContext context)
        {
            _context = context;
        }

        public void AddMovie(Movie movie)
        {
            _context.Movies.Add(movie);
            _context.SaveChanges();
        }

        public Movie GetMovie(int id) => _context.Movies.FirstOrDefault(m => m.Id == id);

        public void UpdateMovie(Movie updatedMovie)
        {
            var movie = _context.Movies.FirstOrDefault(m => m.Id == updatedMovie.Id);
            if (movie != null)
            {
                movie.Title = updatedMovie.Title;
                movie.Rating = updatedMovie.Rating;
                movie.Year = updatedMovie.Year;
                movie.Oscars = updatedMovie.Oscars;
                movie.DirectorId = updatedMovie.DirectorId;
                _context.SaveChanges();
            }
            else
            {
                throw new KeyNotFoundException($"Movie with ID {updatedMovie.Id} not found.");
            }
        }

        public void DeleteMovie(int id)
        {
            var movie = _context.Movies.FirstOrDefault(m => m.Id == id);
            if (movie != null)
            {
                _context.Movies.Remove(movie);
                _context.SaveChanges();
            }
            else
            {
                throw new KeyNotFoundException($"Movie with ID {id} not found.");
            }
        }

        public void DeleteByName(string name)
        {
            var forDelete = _context.Movies.Where(movie => movie.Title == name).ToList();

            foreach (var movie in forDelete)
            {
                DeleteMovie(movie.Id);
            }
        }

        public IEnumerable<Movie> GetAllMovies()
        {
            return _context.Movies.ToList();
        }
    }
}
