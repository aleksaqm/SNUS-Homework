﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntityFrameworkHomework
{
    internal class ReportHandler
    {
        private readonly ImdbContext _context;

        public ReportHandler(ImdbContext context)
        {
            _context = context;
        }

        public void MoviesByDirector()
        {
            var result = _context.Movies
                .Include("Director")
                .GroupBy(m => new { m.DirectorId, m.Director.Name })
                .Select(group => new
                {
                    DirectorName = group.Key.Name,
                    Movies = group.Select(m => m.Title).ToList()
                })
                .ToList();

            foreach (var group in result)
            {
                Console.WriteLine($"\t Director - {group.DirectorName}");
                foreach (var movie in group.Movies)
                {
                    Console.WriteLine($"\t\t Movie - {movie}");
                }
            }
        }

        public void DirectorForMovies()
        {
            var result = _context.Movies
                .Select(m => new
                {
                    MovieTitle = m.Title,
                    DirectorName = m.Director.Name
                }).ToList();

            foreach (var movie in result)
            {
                Console.WriteLine($"\t Movie: {movie.MovieTitle}, Director: {movie.DirectorName}");
            }
        }

        public void TopNRankedMovies(int n)
        {
            var result = _context.Movies
                .OrderByDescending(m => m.Rating)
                .Take(n)
                .Select(m => new
                {
                    MovieTitle = m.Title,
                    Rating = m.Rating
                }).ToList();

            foreach (var movie in result)
            {
                Console.WriteLine($"\t Movie: {movie.MovieTitle}, Rating: {movie.Rating}");
            }
        }

        public void DirectorsAndTheirOscars()
        {
            var result = _context.Movies
                .GroupBy(m => m.DirectorId)
                .Select(group => new
                {
                    DirectorId = group.Key,
                    TotalOscars = group.Sum(m => m.Oscars)
                })
                .Join(_context.Directors,
                    moviesGroup => moviesGroup.DirectorId,
                    director => director.Id,
                    (moviesGroup, director) => new
                    {
                        DirectorName = director.Name,
                        Oscars = moviesGroup.TotalOscars
                    })
                .ToList();

            foreach (var director in result)
            {
                Console.WriteLine($"\t Director: {director.DirectorName}, Oscars: {director.Oscars}");
            }
        }

        public void DirectorsWithMoreThanTwoOscars()
        {
            var result = _context.Movies
                .GroupBy(m => m.DirectorId)
                .Select(group => new
                {
                    DirectorId = group.Key,
                    TotalOscars = group.Sum(m => m.Oscars)
                })
                .Where(g => g.TotalOscars > 2)
                .Join(_context.Directors,
                    moviesGroup => moviesGroup.DirectorId,
                    director => director.Id,
                    (moviesGroup, director) => new
                    {
                        DirectorName = director.Name,
                        TotalOscars = moviesGroup.TotalOscars
                    })
                .ToList();

            foreach (var director in result)
            {
                Console.WriteLine($"\t Director: {director.DirectorName}, Oscars: {director.TotalOscars}");
            }
        }

        public void LivingDirectorsWithAtLeastTwoOscars()
        {
            var result = _context.Directors
                .Where(d => d.Died == null && d.Oscars >= 2)
                .Select(d => new {d.Name, d.Oscars})
                .ToList();

            foreach (var director in result)
            {
                Console.WriteLine($"\t{director.Name}, Oscars : {director.Oscars}");
            }
        }
    }
}
