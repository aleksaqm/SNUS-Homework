﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntityFrameworkHomework
{
    public class Movie
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [StringLength(100, MinimumLength = 3)]
        public string Title { get; set; }

        [Required]
        [Range(0, 10)]
        public double Rating { get; set; }

        [Required]
        public int Year { get; set; }

        [Required]
        [Range(0, int.MaxValue)]
        public int Oscars { get; set; }

        [Required]
        [ForeignKey("Director")]
        public int DirectorId { get; set; }
        public Director Director { get; set; }

        public override string ToString()
        {
            return $"{Title} ({Year}, directed by {Director?.Name}) - won {Oscars} Oscars and has rating : {Rating} ";
        }

        public Movie()
        {
        }

        public Movie(int id, string title, double rating, int year, int oscars, int directorId, Director director)
        {
            Id = id;
            Title = title;
            Rating = rating;
            Year = year;
            Oscars = oscars;
            DirectorId = directorId;
            Director = director;
        }
    }
}
