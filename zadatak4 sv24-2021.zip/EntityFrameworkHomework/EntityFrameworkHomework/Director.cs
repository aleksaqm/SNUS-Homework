﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntityFrameworkHomework
{
    public class Director
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [StringLength(50, MinimumLength = 5)]
        public string Name { get; set; }

        [Required]
        [Range(0, int.MaxValue)]
        public int Oscars { get; set; }

        [Required]
        public DateTime Born { get; set; }
        public DateTime? Died { get; set; }

        public override string ToString()
        {
            return $"{Name}, won {Oscars} Oscars, ({Born} - {Died})";

        }

        public Director()
        {

        }

        public Director(int id, string name, int oscars, DateTime born, DateTime? died)
        {
            Id = id;
            Name = name;
            Oscars = oscars;
            Born = born;
            Died = died;
        }

    }
}
